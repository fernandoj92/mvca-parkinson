#!/bin/sh
java -Xmx2048m -Xms256m -cp latlab-obf.jar:colt.jar:commons-cli-1.2.jar Classify $*
