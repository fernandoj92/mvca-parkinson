This directory contains the Java implementation of the PLTM algorithm described
in the paper "Variable selection in model-based clustering: To do or to 
facilitate" (ICML 2010).  It also contains the sub-directory data where
data sets in ARFF format can be found.

The directory includes shell scripts for running on Unix machines.  
To learn PLTM (named output.bif) on a data set (e.g. data/iris.arff):

> ./run.sh data/iris.arff

To specify the output file name:

> ./run.sh -o iris.bif data/iris.arff

To evaluate a model using NMI:

> ./evaluateNMI.sh data/iris.arff iris.bif

This script also accepts multiple model files, such as:

> ./evaluateNMI.sh data/iris.arff iris*.bif

In case other measures are used for evaluating the clusterings, the marginal 
probabilities of the latent variables for every data cases can be computed by:

> ./classify.sh data/iris.arff iris.bif

It will generate several CSV files, each of which contains the marginal 
probabilities of a latent variable for every data case.  It will also
generate a CSV file for the class variable.

For any inquiries, please email lkmpoon [at] cse.ust.hk.